CREATE DATABASE retailmart;
